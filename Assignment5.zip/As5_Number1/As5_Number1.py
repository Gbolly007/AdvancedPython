# Python Version 3.8
import AssessmentPDFLib


if __name__ == "__main__":
    # nothing useful
    # just to make sure your merge doesn’t crash! print("hello")
    print("hello")
