# Python Version 3.8
from AssessmentPDFLib import *


@stat_object
@stat_complexity
def foo():
    print("hello")


if __name__ == "__main__":
    foo()
