# Python Version 3.8
from AssessmentPDFLib import *


@report_object
@report_complexity
def foo():
    print("hello")


if __name__ == "__main__":
    foo()
    report_object = report_object(report_object)
    report_object(report_object)
    report_complexity = report_complexity(report_complexity)
    report_complexity(report_complexity)
